<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Breakdown;
use App\Models\Random;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class ExamController extends Controller
{
    public function index()
    {



    	$r_names = Str::random(10);

    	$fh_names = Str::substr($r_names, 0,5);

    	$lh_names = Str::substr($r_names, 5,5);

    	$randoms = Random::all();

    	$breakdowns = Breakdown::all();

        DB::table('randoms')->insert(
			array(
				'values' => $r_names,
				'flag' => 0,
				));


		$id = DB::table('randoms')->where('values',$r_names)->pluck('id');

        $undisplayed = DB::table('randoms')->where('flag',0)->pluck('flag');
       

        $r_id = str::substr($id,2,2);

        $ud = str::substr($undisplayed,2,1);

        $contains = Str::contains($r_names,[$fh_names,$lh_names]);

		

        $validation = $r_id -1;

       

                    if ($contains == true ) {
                    DB::table('breakdowns')->insert(
                        array(
                            'values'=>$fh_names,
                            'random_id' => $r_id
                    ));

                    DB::table('breakdowns')->insert(
                        array(
                            'values'=>$lh_names,
                            'random_id' => $r_id
                    ));

                    
                    }
            
            // //check if the data is already displayed, if not update all undisplayed data
            // if($validation < $r_id)
            // {
            //     return $this->displayed();
            // }

    		return view('exam',compact('randoms','breakdowns'));
    }

    public function displayed()
    {
        DB::table('randoms')->where('flag',0)->increment('flag', 1);
    }

}
