<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Exam</title>

    </head>

    <style type="text/css">
    a.fx-Revolve 
    { 
        &:focus 
        {
        // outline: 0;
        box-shadow: 0 0 3pt 2pt #75ACF8;
        position: relative;
        outline: 0;
            &:before {
            border-radius: inherit;
            content: "";
            width: calc(100% - 2.2em);
            height: calc(100% - 2.2em);
            margin: 1em;
            box-shadow: inset 0 0 3pt 2pt #75ACF8;
            position: absolute;
            left: 0;
            top: 0;
            }
        }
    }
    </style>

    <script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.js')); ?>"></script>


    <body>
    <h1>There is no undisplayed data yet. Refresh the page to see the datas.</h1>

    <svg xmlns="http://www.w3.org/2000/svg" width="50%" heihgt="50%" viewBox="0 150 744 1052">

    <defs>
    <path id="MyPath" d="m351 487c0 8-11 4-14-1-6-11 4-24 15-27 19-5 37 11 40 30 4 27-18 50-44 53-35 4-64-25-66-59-3-42 32-77 73-79 50-3 90 39 92 88 2 57-46 104-102 105-65 2-117-53-119-117-1-72 60-131 131-132 80-1 144 67 145 146 1 87-74 158-160 158-95 0-171-81-171-175 0-102 88-185 190-184 110 1 198 95 197 204C557 615 456 709 340 708 215 706 115 598 117 475 119 342 233 236 364 238 504 240 616 361 614 500 611 648 484 766 337 763 182 760 58 626 61 472 65 309 206 179 367 183c170 4 306 151 302 320-4 178-158 319-335 315" />
    </defs>

    <use xlink:href="#MyPath" fill="none" stroke-width="0.1" stroke="white"  />
    
    <text font-family="Verdana" font-size="20">
    <textPath xlink:href="#MyPath">
        <?php $__currentLoopData = $randoms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $random): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($random->flag == 0): ?>
        
            <?php echo e($random->values); ?>

        
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $breakdowns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $breakdown): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php echo e($breakdown->values); ?>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </textPath>
    </text>
</svg>
    

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\Ocampo_Exam\resources\views/exam.blade.php ENDPATH**/ ?>